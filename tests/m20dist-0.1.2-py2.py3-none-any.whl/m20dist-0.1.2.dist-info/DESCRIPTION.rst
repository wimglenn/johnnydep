default long text for PyPI landing page 💩


