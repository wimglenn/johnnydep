This is the long description for fakedist

Here is the unicode PILE OF POOP in utf-8: 💩


