from setuptools import setup

setup(
    name="jdt4",
    version="0.1",
)
