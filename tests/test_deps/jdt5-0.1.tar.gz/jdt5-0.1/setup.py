from setuptools import setup

setup(
    name="jdt5",
    version="0.1",
)
