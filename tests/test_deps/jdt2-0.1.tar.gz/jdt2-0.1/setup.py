from setuptools import setup

setup(
    name="jdt2",
    version="0.1",
    install_requires=["jdt3", "jdt4"],
)
