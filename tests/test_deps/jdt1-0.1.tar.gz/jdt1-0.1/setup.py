from setuptools import setup

setup(
    name="jdt1",
    version="0.1",
    install_requires=["jdt2", "jdt5"],
)
