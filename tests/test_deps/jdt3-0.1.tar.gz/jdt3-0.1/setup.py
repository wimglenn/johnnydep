from setuptools import setup
import os

if os.environ.get("JDT3_FAIL"):
    raise Exception("jdt3 intentionally crashing")

setup(
    name="jdt3",
    version="0.1",
)
